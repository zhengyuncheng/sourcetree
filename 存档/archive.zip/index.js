// 教学只推fun3

function fun3(){
  console.log('fun3')
}